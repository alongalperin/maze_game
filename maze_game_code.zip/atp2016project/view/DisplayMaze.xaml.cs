﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ATP2016Project.View
{
    /// <summary>
    /// Interaction logic for DisplayMaze.xaml
    /// </summary>
    public partial class DisplayMaze : Window
    
    {
        public string m_choosenMaze;

        public DisplayMaze()
        {
            InitializeComponent();
            comboBox.Items.Insert(0, "Please select any value");
            comboBox.SelectedIndex = 0;
        }

        public void updateComboBox(List<string> mazes)
        {
            foreach (string item in mazes)
            {
                comboBox.Items.Add(item);
            }
        }

        private void DisplayButton_Click(object sender, RoutedEventArgs e)
        {
            if (comboBox.SelectedIndex == 0)
            {
                MessageBox.Show("please choose maze");
                m_choosenMaze = "";
            }
            else
            {
                m_choosenMaze = comboBox.SelectedValue.ToString();
                this.DialogResult = true;
            }
        }
    }
}
