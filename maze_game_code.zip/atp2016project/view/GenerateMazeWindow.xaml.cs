﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace ATP2016Project.View
{
    /// <summary>
    /// Interaction logic for GenerateMaze.xaml
    /// </summary>
    public partial class GenerateMazeWindow : Window
    {
        private string field_name;
        private int field_height;
        private int field_width;
        private int field_floors;


        public GenerateMazeWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string errorReporting = "";
            if (textBoxName.Text.ToString() == "") // name wasn't entered
            {
                errorReporting += "please enter name to the maze\n\n";
            }
            else // name entered currectly
            {
                Name = textBoxName.Text.ToString();
            }

            #region check if height is valid

            bool boolHeight = Int32.TryParse(textBoxHeight.Text.ToString() , out field_height);
            if (boolHeight == true && field_height > 0 && field_height < 100)
            {}
            else
            {
                errorReporting += "the height must contain valid number, number between 1 to 99\n\n";
            }
            #endregion

            #region check if width is valid

            bool boolWidth = Int32.TryParse(textBoxWidth.Text.ToString(), out field_width);
            if (boolWidth == true && field_width > 0 && field_width < 100)
            {}
            else
            {
                errorReporting += "the width must contain valid number, number between 1 to 99\n\n";
            }
            #endregion

            #region check if floors is valid

            bool boolFloors = Int32.TryParse(textBoxFloors.Text.ToString(), out field_floors);
            if (boolFloors == true && field_floors > 0 && field_floors < 20)
            {}
            else
            {
                errorReporting += "the floors must contain valid number, number between 1 to 20\n\n";
            }
            #endregion

            if (errorReporting!= "")
            {
                MessageBox.Show(errorReporting);
                this.DialogResult = false;
            }
            else
            {
                this.DialogResult = true;
            }
        }

        public string Name
        {
            get { return field_name; }
            set { field_name = value; }
        }

        public int Height
        {
            get { return field_height; }
            set { field_height = value; }
        }

        public int Width
        {
            get { return field_width; }
            set { field_width = value; }
        }

        public int Floors
        {
            get { return field_floors; }
            set { field_floors = value; }
        }

        private void Exit_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}
