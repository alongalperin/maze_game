﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ATP2016Project.View;
using ATP2016.MazeGenerators;
using Microsoft.Win32;
using System.Collections;
using System.Threading;
using System.Windows.Controls.Primitives;

namespace ATP2016Project
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window , IView
    {
        public event viewEventDelegate ViewChanged;
        private List<string> m_generatedMazes;
        bool isMazeDisplayed;
        string strCurrentMaze;
        Maze3d mazeCurrentMaze;

        public MainWindow()
        {
            InitializeComponent();
            mazeDisplayer.Visibility = System.Windows.Visibility.Hidden;
            isMazeDisplayed = false;
            intro.Visibility = System.Windows.Visibility.Visible;
            popUp();
        }

        private void popUp()
        {
            var result = System.Windows.MessageBox.Show("Do you want to first open the Instructions?", "Help", MessageBoxButton.YesNo, MessageBoxImage.Question);
            if (result == MessageBoxResult.Yes)
            {
                HelpWindow iw = new HelpWindow();
                iw.ShowDialog();
            }
        }

        private void GenerateMaze_clicked(object sender, RoutedEventArgs e)
        {
            GenerateMazeWindow gmw = new GenerateMazeWindow();
            gmw.Owner = this;
            gmw.ShowDialog();
            if (gmw.DialogResult == true)
            {
                int _height = gmw.Height;
                int _width = gmw.Width;
                int _floors = gmw.Floors;
                string _name = gmw.Name.Trim().ToLower().ToString();
                ViewChanged("generatemaze " + _name + " " + _height + " " + _width + " " + _floors);
            }
            else
            {
                MessageBox.Show("didnt finish submitting the details");
            }
        }

        public void Start()
        {
            this.Show();
        }

        public void DisplayMessage(string info)
        {
            MessageBox.Show(info);
            txt_log.Text = info + "\n" + txt_log.Text;
        }

        public void displayFloor(byte[] mazeInBytes)
        {
            mazeDisplayer.DrewFloor(mazeInBytes);
        }

        public void setStartAndGoalPoints(Position _startPoint, Position _goalPoint)
        {
            mazeDisplayer.setStartAndGoalPoints(_startPoint, _goalPoint);
        }


        public void setDimentions(int[] dimentions)
        {
            mazeDisplayer.setDimentions(dimentions);
        }

        private void SaveMaze_Clicked(object sender, RoutedEventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "maze files (*.maze)|*.maze";
            saveFileDialog.Title = "Save Current Maze";
            saveFileDialog.FilterIndex = 1;
            saveFileDialog.RestoreDirectory = true;

            if (saveFileDialog.ShowDialog() == true)
            {
                ViewChanged("SaveMaze " + saveFileDialog.FileName);
            }
        }

        private void LoadMaze_Clicked(object sender, RoutedEventArgs e)
        {
            LoadMazeWindow lmw = new LoadMazeWindow();
            lmw.Owner = this;
            lmw.ShowDialog();

            string mazeName = lmw.getMazeName();
            string path = lmw.getFilePath();

            if (mazeName != null && path != null)
            {
                ViewChanged("loadmaze " + mazeName + " " + path);
            }
        }

        public bool CheckIfMazeExists(string mazeName, bool ans)
        {
            ViewChanged("checkExistingMaze " + mazeName);
            return ans;
        }


        public void ToggleMazeDisplay(string message)
        {
            if (message != "")
            {
                DisplayMessage(message);
            }
            if (isMazeDisplayed == true)
            { // hide the maze
                mazeDisplayer.Visibility = System.Windows.Visibility.Hidden;
                intro.Visibility = System.Windows.Visibility.Visible;
                RemoveCurrentMaze();
                isMazeDisplayed = false;
            } else { // show the maze
                mazeDisplayer.Visibility = System.Windows.Visibility.Visible;
                intro.Visibility = System.Windows.Visibility.Hidden;
                isMazeDisplayed = true;
            }
        }

        private void DisplayMaze_clicked(object sender, RoutedEventArgs e)
        {
            DisplayMaze dmw = new DisplayMaze();
            dmw.Owner = this;
            ViewChanged("GetGeneratedMazes");
            dmw.updateComboBox(m_generatedMazes);
            dmw.ShowDialog();

            if (dmw.DialogResult == true)
            {
                if ( dmw.m_choosenMaze != "") // a maze was chooned to display
                {
                    ViewChanged("displaymaze " + dmw.m_choosenMaze);
                }
            }
        }

        public void setGeneratedMazes(List<string> listGeneratedMazes)
        {
            this.m_generatedMazes = listGeneratedMazes;
        }


        public void displayMaze(String mazeName, Maze3d maze)
        {
            strCurrentMaze = mazeName;
            setMaze(maze);
            if (isMazeDisplayed == false) // we need to hide the intro and show tha maze
            {
                ToggleMazeDisplay("");
            }
            else
            {
                isMazeDisplayed = false;
                ToggleMazeDisplay("");
            }
            mazeDisplayer.displayMaze();
        }

        private void SolveMaze_Clicked(object sender, RoutedEventArgs e)
        {
            ViewChanged("solvemaze " + strCurrentMaze);
        }

        private void DisplaySolution(object sender, RoutedEventArgs e)
        {
            if (strCurrentMaze != null)
            {
                ViewChanged("DisplaySolution " + strCurrentMaze);
            }
            else //maze dispalayer not exists yet
            {
                MessageBox.Show("please display maze first");
            }
        }

        public void setSolutionSteps(ArrayList list)
        {
            mazeDisplayer.setSolutionSteps(list);
        }

        public void setDisplaySoutionMode(bool _isSulotion)
        {
            mazeDisplayer.isSolutionMode = _isSulotion;
        }

        private void Window_KeyDown(object sender, KeyEventArgs e)
        {
            string keyPressed = e.Key.ToString().ToLower();
            switch (keyPressed)
            {
                case "pageup":
                    ViewChanged("keypressed " + strCurrentMaze + " " + mazeDisplayer.getPlayerY() + " " + mazeDisplayer.getPlayerX() + " " + mazeDisplayer.currentFloor + " " + "pageup");
                    break;
                case "next":
                    ViewChanged("keypressed " + strCurrentMaze + " " + mazeDisplayer.getPlayerY() + " " + mazeDisplayer.getPlayerX() + " " + mazeDisplayer.currentFloor +" "+"next");
                    break;
                case "left":
                    mazeDisplayer.DrewPlayer("left");
                    ViewChanged("keypressed " + strCurrentMaze + " " + mazeDisplayer.getPlayerY() + " " + mazeDisplayer.getPlayerX() + " " + mazeDisplayer.currentFloor +" "+"left");
                    break;
                case "up":
                    mazeDisplayer.DrewPlayer("up");
                    ViewChanged("keypressed " + strCurrentMaze + " " + mazeDisplayer.getPlayerY() + " " + mazeDisplayer.getPlayerX() + " " + mazeDisplayer.currentFloor +" "+"up");
                    break;
                case "right":
                    mazeDisplayer.DrewPlayer("right");
                    ViewChanged("keypressed " + strCurrentMaze + " " + mazeDisplayer.getPlayerY() + " " + mazeDisplayer.getPlayerX() + " " + mazeDisplayer.currentFloor +" "+"right");
                    break;
                case "down":
                    mazeDisplayer.DrewPlayer("down");
                    ViewChanged("keypressed " + strCurrentMaze + " " + mazeDisplayer.getPlayerY() + " " + mazeDisplayer.getPlayerX() + " " + mazeDisplayer.currentFloor +" "+"down");
                    break;
            }
        }

        public void Move(string isPosible)
        {
            string[] splitedCommand = isPosible.Trim().Split(' ');
            string direction = splitedCommand[0];
            string upDown = "";
            if (splitedCommand.Length > 1)
            {
                upDown = splitedCommand[1];
            }
            ShowUpDownArrows(upDown);

            switch (direction)
            {
                case "left":
                    mazeDisplayer.Move("left");
                    break;
                case "up":
                    mazeDisplayer.Move("up");
                    break;
                case "right":
                    mazeDisplayer.Move("right");
                    break;
                case "down":
                    mazeDisplayer.Move("down");
                    break;
                case "pageup":
                    mazeDisplayer.Move("floorup");
                    break;
                case "next":
                    mazeDisplayer.Move("floordown");
                    break;
                case "goal":
                    string goalDirection = splitedCommand[1];
                    mazeDisplayer.Move(goalDirection);
                    ViewChanged("finishgame");
                    break;
            }
        }

        private void ShowUpDownArrows(string upDown)
        {
            if (upDown == "both")
            {
                // add up green sign
                mazeDisplayer.DetailsPanelDisplayer.pageUp.Source = new BitmapImage(new Uri("pack://application:,,,/View/Images/PageUPGreen.png"));
                // add down green sign
                mazeDisplayer.DetailsPanelDisplayer.pageDown.Source = new BitmapImage(new Uri("pack://application:,,,/View/Images/PageDownGreen.png"));
            }
            if (upDown == "down")
            {
                mazeDisplayer.DetailsPanelDisplayer.pageUp.Source = new BitmapImage(new Uri("pack://application:,,,/View/Images/PageUpRed.png"));
                mazeDisplayer.DetailsPanelDisplayer.pageDown.Source = new BitmapImage(new Uri("pack://application:,,,/View/Images/PageDownGreen.png"));
            }
            if (upDown == "up")
            {
                mazeDisplayer.DetailsPanelDisplayer.pageUp.Source = new BitmapImage(new Uri("pack://application:,,,/View/Images/PageUPGreen.png"));
                mazeDisplayer.DetailsPanelDisplayer.pageDown.Source = new BitmapImage(new Uri("pack://application:,,,/View/Images/PageDownRed.png"));
            }
            if (upDown == "")
            {                
                mazeDisplayer.DetailsPanelDisplayer.pageUp.Source = new BitmapImage(new Uri("pack://application:,,,/View/Images/PageUpRed.png"));
                mazeDisplayer.DetailsPanelDisplayer.pageDown.Source = new BitmapImage(new Uri("pack://application:,,,/View/Images/PageDownRed.png"));

            }
        }

        public void FinishGame()
        {
            int milliseconds = 300;
            Thread.Sleep(milliseconds);
            GoalReached goalReached = new GoalReached();
            goalReached.Owner = this;
            goalReached.ShowDialog();
            ToggleMazeDisplay("try to play another round");
            RemoveCurrentMaze();
        }


        public void setMaze(Maze3d _maze)
        {
            mazeDisplayer.DetailsPanelDisplayer.mazeName = strCurrentMaze;
            mazeDisplayer.DetailsPanelDisplayer.goalFloor = _maze.getGoalPoint().Floor;
            mazeDisplayer.setMaze(_maze);
        }


        public int GetCurrentFloor()
        {
            return mazeDisplayer.currentFloor;
        }


        public void RemoveCurrentMaze()
        {
            this.mazeCurrentMaze = null;
            this.strCurrentMaze = "";
            this.isMazeDisplayed = false;
            mazeDisplayer.m_solutionStepsHash.Clear();
        }

        private void Help_Clicked(object sender, RoutedEventArgs e)
        {
            HelpWindow iw = new HelpWindow();
            iw.Owner = this;
            iw.ShowDialog();
        }

        private void About_Clicked(object sender, RoutedEventArgs e)
        {
            AboutWindow wh = new AboutWindow();
            wh.Owner = this;
            wh.ShowDialog();
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            ViewChanged("exit");
        }

        private void Exit_Clicked(object sender, RoutedEventArgs e)
        {
            ViewChanged("exit");
            this.Close();
        }

        public bool isSetStepsConfigured()
        {
            return mazeDisplayer.m_solutionStepsHash.Count != 0;
        }
    }
}
