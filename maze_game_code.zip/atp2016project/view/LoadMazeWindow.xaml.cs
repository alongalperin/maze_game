﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using ATP2016Project.Presenter;

namespace ATP2016Project.View
{
    /// <summary>
    /// Interaction logic for LoadMazeWindow.xaml
    /// </summary>
    public partial class LoadMazeWindow : Window
    {
        private string pathToLoad;
        private string mazeName;

        public LoadMazeWindow()
        {
            InitializeComponent();
        }

        private void LoadBrowse_click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Maze files (*.maze)|*.maze";
            if (openFileDialog.ShowDialog() == true)
            {
                pathToLoad = openFileDialog.FileName;
            }
        }

        private void Load_Button(object sender, RoutedEventArgs e)
        {
            mazeName = mazeNameLoadTextBox.Text.Trim().ToLower();
            this.Close();
        }

        public string getFilePath()
        {
            return pathToLoad;
        }

        public string getMazeName()
        {
            return mazeName;
        }
    }
}
