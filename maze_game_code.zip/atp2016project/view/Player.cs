﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ATP2016Project.View
{
    public class Player
    {
        private int m_x;
        private int m_y;
        private int m_z;
        private int m_prevX;
        private int m_prevY;
        
        public Player(int row, int column)
        {
            x = column;
            y = row;
            m_prevX = -1;
            m_prevY = -1;
        }

        public int x
        {
            get { return m_x; }
            set { m_x = value; }
        }
        public int y
        {
            get { return m_y; }
            set { m_y = value; }
        }

        public int prevX
        {
            get { return m_prevX; }
            set { m_prevX = value; }
        }
        public int prevY
        {
            get { return m_prevY; }
            set { m_prevY = value; }
        }
        public int z
        {
            get { return m_z; }
            set { m_z = value; }
        }
    }
}
