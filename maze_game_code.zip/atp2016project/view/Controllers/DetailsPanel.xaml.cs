﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ATP2016Project.View.Controllers
{
    /// <summary>
    /// Interaction logic for DetailsPanel.xaml
    /// </summary>
    public partial class DetailsPanel : UserControl
    {
        private string m_currentMazeName;
        private int m_goalFloor;
        private int m_currentFloor;

        public DetailsPanel()
        {
            InitializeComponent();
        }

        public int currentFloor
        {
            get { return m_currentFloor; }
            set { 
                m_currentFloor = value;
                lbl_currentFloor.Text = m_currentFloor.ToString();
            }
        }

        public int goalFloor
        {
            get { return m_goalFloor; }
            set { 
                m_goalFloor = value;
                lbl_goalFloor.Text = m_goalFloor.ToString();
            }
        }

        public string mazeName
        {
            get { return m_currentMazeName; }
            set { 
                m_currentMazeName = value;
                lbl_currentMaze.Text = m_currentMazeName;
            }
        }
    }
}
