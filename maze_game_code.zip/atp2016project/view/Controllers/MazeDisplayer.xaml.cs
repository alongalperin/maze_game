﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ATP2016.MazeGenerators;
using ATP2016.Search;
using System.Collections;
using ATP2016Project.View.Controllers;

namespace ATP2016Project.View
{
    /// <summary>
    /// Interaction logic for MazeDisplayer.xaml
    /// </summary>
    /// 
    public partial class MazeDisplayer : UserControl
    {
        public Position startPoint;
        public Position goalPoint;
        public int currentFloor = 0;        
        private int m_heightCurrentMaze;
        private int m_widthCurrentMaze;
        private int m_floorsCurrentMaze;
        public bool isSolutionMode;
        public HashSet<string> m_solutionStepsHash;
        private Player m_player;
        Maze3d m_currentMaze;

        public MazeDisplayer()
        {
            InitializeComponent();
            m_solutionStepsHash = new HashSet<string>();
        }

        public void setStartAndGoalPoints(Position _startPoint, Position _goalPoint)
        {
            startPoint = _startPoint;
            goalPoint = _goalPoint;
        }

        public void setGrid(int height, int width)
        {
            m_heightCurrentMaze = height;
            m_widthCurrentMaze = width;
            gridMazeDisplayer.ColumnDefinitions.Clear();
            gridMazeDisplayer.RowDefinitions.Clear();

            for (int i = 0; i < height; i++) // set the columns
            {
                ColumnDefinition columnDefinition = new ColumnDefinition();
                gridMazeDisplayer.ColumnDefinitions.Add(columnDefinition);
            }
            for (int i = 0; i < width; i++) // set the rows
            {
                RowDefinition rowDefinition = new RowDefinition();
                gridMazeDisplayer.RowDefinitions.Add(rowDefinition);
            }

        }

        public void DrewFloor(byte[] floor)
        {
            setGrid(m_heightCurrentMaze, m_widthCurrentMaze);
            int index = 0;
            string typeOfCell = "";

            for (int i = 0; i < m_heightCurrentMaze; i++)
            {
                for (int j = 0; j < m_widthCurrentMaze; j++)
                {
                    Position p = new Position(i, j, currentFloor); // we create position from the current cell we want to print. this position will help us to check start point goal point and solution
                    Label l = new Label();
                    if (isSolutionMode == false) // normal printing
                    {
                        if (floor[index] == 0)
                        {
                            typeOfCell = "empty";
                        }
                        else if (floor[index] == 1)
                        {
                            typeOfCell = "wall";
                        }
                    }
                    if (isSolutionMode == true)
                    {
                        if (m_solutionStepsHash.Contains(p.ToString())) // solution printing
                        {
                            typeOfCell = "solve";
                        }
                        else if (floor[index] == 0)
                        {
                            typeOfCell = "empty";
                        }
                        else
                        {
                            typeOfCell = "wall";
                        }
                    }

                    // check start or goal point
                    if (p.Equals(startPoint))
                    {
                        typeOfCell = "start";
                    }

                    if (p.Equals(goalPoint))
                    {
                        typeOfCell = "goal";
                    }

                    MyCell cell = new MyCell(typeOfCell);
                    gridMazeDisplayer.Children.Add(cell);
                    Grid.SetRow(cell, j);
                    Grid.SetColumn(cell, i);

                    index++;
                }
            }
            DrewPlayer("right");
        }

        public void setDimentions(int[] dimentions)
        {
            m_heightCurrentMaze = dimentions[0];
            m_widthCurrentMaze = dimentions[1];
            m_floorsCurrentMaze = dimentions[2];
        }

        public void displayMaze()
        {
            Maze3d maze = m_currentMaze;
            int[] dimentions = { maze.Height, maze.Width , maze.Floors};
            setDimentions(dimentions);

            setStartAndGoalPoints(maze.startPoint, maze.goalPoint);

            setGrid(maze.Height, maze.Width);
            byte[] firstFloorInBytes = maze.m_lFloors[0].toByteArray();
            DetailsPanelDisplayer.currentFloor = 0;
            DetailsPanelDisplayer.pageUp.Source = new BitmapImage(new Uri("pack://application:,,,/View/Images/PageUpRed.png"));
            DetailsPanelDisplayer.pageDown.Source = new BitmapImage(new Uri("pack://application:,,,/View/Images/PageDownRed.png"));
            DrewFloor(firstFloorInBytes);
        }

        public void setSolutionSteps(ArrayList solutionSteps)
        {
            // we create hashSet with the steps to solution
            foreach (AState p in solutionSteps)
            {
                string positionSTR = p.GetState();
                m_solutionStepsHash.Add(positionSTR);
            }
        }

        // drewing player
        public void DrewPlayer(string direction)
        {
            string typeOfCell;
            if (m_player.prevX == -1 || m_player.prevY == -1)
            {
                typeOfCell = "startPlayer";
            }
            else
            {
                typeOfCell = direction;
            }
            MyCell mc = new MyCell(typeOfCell);
            gridMazeDisplayer.Children.Add(mc);
            Grid.SetColumn(mc, m_player.x);
            Grid.SetRow(mc, m_player.y);

            // delete the previous grid cell the player was in
            string strEmptyCell = "";
            if (m_player.prevX != -1 || m_player.prevY != -1)
            {
                if (isSolutionMode == false)
                {
                    strEmptyCell = "empty";
                }
                else
                {
                    Position p = new Position(m_player.prevX, m_player.prevY , currentFloor);
                    if (m_solutionStepsHash.Contains(p.ToString())) // solution printing
                    {
                        strEmptyCell = "solve";
                    }
                    else
                    {
                        strEmptyCell = "empty";
                    }
                }
                MyCell emptyCell = new MyCell(strEmptyCell);
                gridMazeDisplayer.Children.Add(emptyCell);
                Grid.SetColumn(emptyCell, m_player.prevX);
                Grid.SetRow(emptyCell, m_player.prevY);
            }
        }

        public void setMaze(Maze3d maze)
        {
            this.m_currentMaze = maze;
            m_player = new Player(m_currentMaze.getStartPoint().Col , m_currentMaze.getStartPoint().Row);
        }

        public void Move(string direction)
        {
            switch (direction)
            {
                case "left":
                    m_player.prevX = m_player.x;
                    m_player.prevY = m_player.y;
                    m_player.x--;
                    DrewPlayer("left");
                    break;
                case "up":
                    m_player.prevY = m_player.y;
                    m_player.prevX = m_player.x;
                    m_player.y--;
                    DrewPlayer("up");
                    break;
                case "right":
                    m_player.prevX = m_player.x;
                    m_player.prevY = m_player.y;
                    m_player.x++;
                    DrewPlayer("right");
                    break;
                case "down":
                    m_player.prevY = m_player.y;
                    m_player.prevX = m_player.x;
                    m_player.y++;
                    DrewPlayer("down");
                    break;
                case "floorup":
                    m_player.z++;
                    currentFloor++;
                    DetailsPanelDisplayer.currentFloor = currentFloor;
                    DrewFloor(m_currentMaze.m_lFloors[currentFloor].toByteArray());
                    DrewPlayer("left");
                    break;
                case "floordown":
                    m_player.z--;
                    currentFloor--;
                    DetailsPanelDisplayer.currentFloor = currentFloor;
                    DrewFloor(m_currentMaze.m_lFloors[currentFloor].toByteArray());
                    DrewPlayer("left");
                    break;
            }
        }

        public int getPlayerX()
        {
            return m_player.x;
        }

        public int getPlayerY()
        {
            return m_player.y;
        }

        public void RemoveCurrentMaze()
        {
            startPoint = null;
            goalPoint = null;
            isSolutionMode = false;
            //m_solutionSteps = null;
            m_solutionStepsHash.Clear();
            m_player.prevX = -1;
            m_player.prevY = -1;
            m_currentMaze = null;
        }
    }
}
