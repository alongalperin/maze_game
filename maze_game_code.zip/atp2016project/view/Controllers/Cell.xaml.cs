﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Drawing;

namespace ATP2016Project.View
{
    /// <summary>
    /// Interaction logic for Cell.xaml
    /// </summary>
    public partial class MyCell : UserControl
    {
        public MyCell(string description)
        {
            InitializeComponent();

            switch (description)
            {
                case "up":
                    cellPicture.Source = new BitmapImage(new Uri("pack://application:,,,/View/Images/up.jpg"));
                    break;
                case "down":
                    cellPicture.Source = new BitmapImage(new Uri("pack://application:,,,/View/Images/down.jpg"));
                    break;
                case "right":
                    cellPicture.Source = new BitmapImage(new Uri("pack://application:,,,/View/Images/right.jpg"));
                    break;
                case "left":
                    cellPicture.Source = new BitmapImage(new Uri("pack://application:,,,/View/Images/left.jpg"));
                    break;
                case "empty":
                    cellPicture.Source = new BitmapImage(new Uri("pack://application:,,,/View/Images/empty.jpg"));
                    break;
                case "wall":
                    cellPicture.Source = new BitmapImage(new Uri("pack://application:,,,/View/Images/wall1.png"));
                    break;
                case "goal":
                    cellPicture.Source = new BitmapImage(new Uri("pack://application:,,,/View/Images/goal.jpg"));
                    break;
                case "solve":
                    cellPicture.Source = new BitmapImage(new Uri("pack://application:,,,/View/Images/solve.jpg"));
                    break;
                case "start":
                    cellPicture.Source = new BitmapImage(new Uri("pack://application:,,,/View/Images/start.png"));
                    break;
                case "startPlayer":
                    cellPicture.Source = new BitmapImage(new Uri("pack://application:,,,/View/Images/startPlayer.jpg"));
                    break;
            }
        }
    }
}