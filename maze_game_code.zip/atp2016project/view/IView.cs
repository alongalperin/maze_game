﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ATP2016.MazeGenerators;
using System.Collections;

namespace ATP2016Project.View
{
    public delegate void viewEventDelegate(string str);
    
    public interface IView
    {
        event viewEventDelegate ViewChanged;

        void Start();

        void DisplayMessage(string name);

        void displayFloor(byte[] mazeInBytes);

        void setStartAndGoalPoints(Position _startPoint, Position _goalPoint);

        void setDimentions(int[] dimentions);

        void ToggleMazeDisplay(string message);  //changeDisplayToPicure

        void setGeneratedMazes(List<string> listGeneratedMazes);

        void displayMaze(string mazeName,Maze3d maze);

        void setDisplaySoutionMode(bool isSolution);

        void setSolutionSteps(ArrayList list);

        void setMaze(Maze3d maze);

        void Move(string isPosible);

        int GetCurrentFloor();

        void RemoveCurrentMaze();

        void FinishGame();

        bool isSetStepsConfigured();
    }
}
